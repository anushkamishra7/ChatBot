import json, random, os
from datetime import datetime
from zoneinfo import ZoneInfo
from flask import Flask, request, jsonify, render_template
from nlp import IntentModel

app = Flask(__name__)
model = IntentModel("model/intent_model.npz")
RESP = {d["tag"]: d["responses"] for d in json.load(open("data/intents.json"))["intents"]}
METRICS = json.load(open("model/metrics.json"))
TZ = ZoneInfo(os.environ.get("BOT_TZ", "Asia/Kolkata"))
THRESH = 0.35

def reply_for(tag):
    r = random.choice(RESP[tag])
    now = datetime.now(TZ)
    return r.replace("__TIME__", "It's " + now.strftime("%I:%M %p").lstrip("0") + ".").replace("__DATE__", "Today is " + now.strftime("%A, %d %B %Y") + ".")

@app.route("/")
def index(): return render_template("index.html", acc=round(METRICS["test_accuracy"]*100, 1))

@app.route("/chat", methods=["POST"])
def chat():
    text = (request.get_json(silent=True) or {}).get("text", "").strip()
    if not text: return jsonify(error="empty text"), 400
    tag, conf, top = model.predict(text[:300])
    if tag is None or conf < THRESH:
        return jsonify(intent="unknown", confidence=conf, top=top, reply="Sorry, I didn't quite understand that. Try asking about the time, weather, jokes, study tips or how I work.")
    return jsonify(intent=tag, confidence=conf, top=top, reply=reply_for(tag))

@app.route("/health")
def health(): return "ok"

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))

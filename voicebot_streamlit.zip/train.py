"""Train a 3-layer MLP (ReLU, dropout, softmax, Adam, L2) for intent classification. Pure NumPy backprop."""
import json, random, numpy as np
from nlp import tokenize, features, vectorize
random.seed(7); rng = np.random.default_rng(7)
data = json.load(open("data/intents.json"))["intents"]
labels = [d["tag"] for d in data]; L = {t:i for i,t in enumerate(labels)}

# stratified split of ORIGINAL utterances (test set is never augmented)
train, test = [], []
for d in data:
    p = d["patterns"][:]; random.shuffle(p)
    k = max(3, int(0.2*len(p)))
    test += [(u, L[d["tag"]]) for u in p[:k]]; train += [(u, L[d["tag"]]) for u in p[k:]]

def augment(u):
    t = tokenize(u); out = []
    if len(t) > 2:
        for _ in range(4):
            r = [w for w in t if random.random() > 0.2] or t
            out.append(" ".join(r))
    fillers = ["please","can you","hey","um","tell me","i want to know"]
    out.append(random.choice(fillers)+" "+u); out.append(u+" "+random.choice(["please","now","for me"]))
    return out
aug = list(train)
for u,y in train: aug += [(a,y) for a in augment(u)]

feats = set()
for u,_ in aug: feats.update(features(tokenize(u)))
vocab = {f:i for i,f in enumerate(sorted(feats))}
def mat(ds): return np.stack([vectorize(u,vocab) for u,_ in ds]), np.array([y for _,y in ds])
Xtr,ytr = mat(aug); Xte,yte = mat(test)
print("vocab",len(vocab),"train",len(Xtr),"test",len(Xte))

D,H1,H2,C = len(vocab),128,64,len(labels)
def he(a,b): return (rng.standard_normal((a,b))*np.sqrt(2/a)).astype(np.float32)
P = {"W0":he(D,H1),"b0":np.zeros(H1,np.float32),"W1":he(H1,H2),"b1":np.zeros(H2,np.float32),"W2":he(H2,C),"b2":np.zeros(C,np.float32)}
m = {k:np.zeros_like(v) for k,v in P.items()}; s = {k:np.zeros_like(v) for k,v in P.items()}
lr,l2,drop,bs,EP = 2e-3,5e-4,0.5,32,25

def fwd(X,train_mode):
    z1=X@P["W0"]+P["b0"]; h1=np.maximum(0,z1); m1=None
    if train_mode: m1=(rng.random(h1.shape)>drop)/(1-drop); h1=h1*m1
    z2=h1@P["W1"]+P["b1"]; h2=np.maximum(0,z2); m2=None
    if train_mode: m2=(rng.random(h2.shape)>drop)/(1-drop); h2=h2*m2
    z=h2@P["W2"]+P["b2"]; z-=z.max(1,keepdims=True); e=np.exp(z); return X,z1,h1,m1,z2,h2,m2,e/e.sum(1,keepdims=True)
def acc(X,y): return float((fwd(X,False)[-1].argmax(1)==y).mean())

t=0; hist=[]
for ep in range(1,EP+1):
    idx=rng.permutation(len(Xtr)); tl=0
    for i in range(0,len(idx),bs):
        b=idx[i:i+bs]; X,y=Xtr[b],ytr[b]
        X,z1,h1,m1,z2,h2,m2,p=fwd(X,True)
        tl+=-np.log(p[np.arange(len(b)),y]+1e-9).sum()
        g=p.copy(); g[np.arange(len(b)),y]-=1; g/=len(b)
        G={}; G["W2"]=h2.T@g; G["b2"]=g.sum(0)
        d2=(g@P["W2"].T)*m2*(z2>0); G["W1"]=h1.T@d2; G["b1"]=d2.sum(0)
        d1=(d2@P["W1"].T)*m1*(z1>0); G["W0"]=X.T@d1; G["b0"]=d1.sum(0)
        t+=1
        for k in P:
            gk=G[k]+(l2*P[k] if k.startswith("W") else 0)
            m[k]=0.9*m[k]+0.1*gk; s[k]=0.999*s[k]+0.001*gk**2
            P[k]-=lr*(m[k]/(1-0.9**t))/(np.sqrt(s[k]/(1-0.999**t))+1e-8)
    hist.append((ep,tl/len(Xtr),acc(Xtr,ytr),acc(Xte,yte)))
    if ep%10==0 or ep==1: print("epoch %2d loss %.4f train_acc %.3f test_acc %.3f"%hist[-1])

pred=fwd(Xte,False)[-1].argmax(1)
cm=np.zeros((C,C),int)
for a,b in zip(yte,pred): cm[a,b]+=1
prec=[cm[i,i]/max(1,cm[:,i].sum()) for i in range(C)]; rec=[cm[i,i]/max(1,cm[i].sum()) for i in range(C)]
f1=[2*p*r/(p+r) if p+r else 0 for p,r in zip(prec,rec)]
res={"vocab_size":len(vocab),"train_samples":len(Xtr),"test_samples":len(Xte),"test_accuracy":acc(Xte,yte),"train_accuracy":acc(Xtr,ytr),
     "macro_f1":float(np.mean(f1)),"history":hist,"per_class":{labels[i]:{"precision":prec[i],"recall":rec[i],"f1":f1[i],"support":int(cm[i].sum())} for i in range(C)},
     "params":int(sum(v.size for v in P.values()))}
json.dump(res,open("model/metrics.json","w"),indent=1)
np.savez("model/intent_model.npz",vocab=np.array(vocab,dtype=object),labels=np.array(labels),**P)
print("TEST ACC",res["test_accuracy"],"macroF1",res["macro_f1"],"params",res["params"])

# VoiceBot - Voice-Enabled Chatbot (Speech Recognition + Deep Learning)

Voice -> text (SpeechRecognition) -> MLP intent classifier (NumPy: ReLU, dropout, softmax, Adam) -> response (shown + spoken).

## Run locally
    pip install -r requirements.txt
    streamlit run streamlit_app.py

## Deploy on Streamlit Community Cloud
share.streamlit.io -> New app -> pick this repo, branch `main`, main file `streamlit_app.py` -> Deploy.

## Files
streamlit_app.py (UI + pipeline) | nlp.py (tokenizer, features, inference) | train.py (training) | build_dataset.py -> data/intents.json | model/ (weights, metrics)
(app.py + templates/ = alternative Flask version)

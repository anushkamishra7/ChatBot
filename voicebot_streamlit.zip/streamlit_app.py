"""Streamlit version of VoiceBot: voice -> text (SpeechRecognition) -> MLP intent classifier -> reply."""
import io, json, random, hashlib
from datetime import datetime
from zoneinfo import ZoneInfo
import streamlit as st
import speech_recognition as sr
from nlp import IntentModel

st.set_page_config(page_title="VoiceBot", page_icon="🎙️", layout="centered")
THRESH, TZ = 0.35, ZoneInfo("Asia/Kolkata")

@st.cache_resource
def load():
    m = IntentModel("model/intent_model.npz")
    resp = {d["tag"]: d["responses"] for d in json.load(open("data/intents.json"))["intents"]}
    return m, resp, json.load(open("model/metrics.json"))
model, RESP, METRICS = load()

def respond(text):
    tag, conf, top = model.predict(text[:300])
    if tag is None or conf < THRESH:
        return "unknown", conf, top, "Sorry, I didn't quite understand that. Try asking about the time, weather, jokes, study tips or how I work."
    now = datetime.now(TZ)
    r = random.choice(RESP[tag]).replace("__TIME__", "It's " + now.strftime("%I:%M %p").lstrip("0") + ".").replace("__DATE__", "Today is " + now.strftime("%A, %d %B %Y") + ".")
    return tag, conf, top, r

def transcribe(wav_bytes):
    rec = sr.Recognizer()
    with sr.AudioFile(io.BytesIO(wav_bytes)) as src:
        audio = rec.record(src)
    return rec.recognize_google(audio, language="en-US")

def tts(text):
    try:
        from gtts import gTTS
        buf = io.BytesIO(); gTTS(text, lang="en").write_to_fp(buf); return buf.getvalue()
    except Exception:
        return None

st.title("🎙️ VoiceBot")
st.caption(f"Speech recognition → deep-learning intent classifier (MLP, {METRICS['params']:,} params) → response · test accuracy {METRICS['test_accuracy']*100:.1f}%")

if "log" not in st.session_state: st.session_state.log, st.session_state.seen = [], set()
heard = None

st.subheader("1. Speak")
audio = st.audio_input("Click the mic, speak, then stop the recording")
if audio is not None:
    data = audio.getvalue(); h = hashlib.md5(data).hexdigest()
    if h not in st.session_state.seen:
        st.session_state.seen.add(h)
        try:
            with st.spinner("Recognising speech..."): heard = transcribe(data)
        except sr.UnknownValueError: st.warning("Couldn't understand the audio. Please speak clearly and try again.")
        except Exception as e: st.error(f"Speech service unavailable ({type(e).__name__}). Use the text box below.")

typed = st.chat_input("...or type a message")
if typed: heard = typed

if heard:
    tag, conf, top, reply = respond(heard)
    st.session_state.log += [("user", heard), ("assistant", reply)]
    st.session_state.last = (heard, tag, conf, top, reply)
    st.session_state.audio = tts(reply)

if "last" in st.session_state:
    heard, tag, conf, top, reply = st.session_state.last
    st.subheader("2. Recognised speech"); st.info(heard)
    st.subheader("3. Chatbot response"); st.success(reply)
    st.caption(f"Intent: **{tag}** · confidence {conf*100:.1f}% · top-3: " + ", ".join(f"{k} {v*100:.0f}%" for k, v in top.items()))
    if st.session_state.get("audio"): st.audio(st.session_state.audio, format="audio/mp3", autoplay=True)

with st.expander("Conversation"):
    for role, msg in st.session_state.log: st.chat_message(role).write(msg)

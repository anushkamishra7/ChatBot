"""Text pre-processing + numpy inference for the intent classifier (no heavy deps needed at deploy time)."""
import re, json, numpy as np

def tokenize(text):
    text = text.lower().replace("what's","what is").replace("how's","how is").replace("i'm","i am").replace("it's","it is").replace("today's","today is")
    return re.findall(r"[a-z0-9]+", text)

def features(tokens):
    """unigrams + bigrams"""
    return tokens + [a+"_"+b for a,b in zip(tokens,tokens[1:])]

def vectorize(text, vocab):
    v = np.zeros(len(vocab), dtype=np.float32)
    for f in features(tokenize(text)):
        i = vocab.get(f)
        if i is not None: v[i] = 1.0
    return v

class IntentModel:
    def __init__(self, path):
        d = np.load(path, allow_pickle=True)
        self.vocab = d["vocab"].item(); self.labels = list(d["labels"])
        self.W = [d[f"W{i}"] for i in range(3)]; self.b = [d[f"b{i}"] for i in range(3)]
    def predict(self, text):
        x = vectorize(text, self.vocab)
        if x.sum() == 0: return None, 0.0, {}
        h = np.maximum(0, x @ self.W[0] + self.b[0])
        h = np.maximum(0, h @ self.W[1] + self.b[1])
        z = h @ self.W[2] + self.b[2]; z -= z.max(); p = np.exp(z); p /= p.sum()
        k = int(p.argmax())
        top = {self.labels[i]: float(p[i]) for i in p.argsort()[::-1][:3]}
        return self.labels[k], float(p[k]), top
